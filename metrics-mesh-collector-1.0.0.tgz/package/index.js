module.exports = { collectIdentity: () => ({ mesh: true }) };
